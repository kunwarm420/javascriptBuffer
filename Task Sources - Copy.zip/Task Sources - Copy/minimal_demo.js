"use strict";
const testlib = require( './testlib.js' );

//nucleo TABLE"
var nucleo={R: ["G", "A"],
 			Y: ["T", "C"],
			K: ["G", "T"],
			M: ["A", "C"],
			S: ["G", "C"],
			W: ["A", "T"],
			B: ["G", "T", "C"],
			D: ["G", "A", "T"],
			H: ["A", "C", "T"],
			V: ["G", "C", "A"],
			N: ["A", "G", "C", "T"]};


const dict={};//key and value pairs
var toCheckKeys;//holds all the keys
let count=0;//counts which offset the stream is at
let buffer=[];//holds longestStrlength amount of
let longestStrLength;//longest a string sequence can be
let sequencetoCheck;
let nucleoKeys=Object.keys(nucleo);//list of keys in nucleoKeys
let nucleoValues=Object.values(nucleo);//list of values in nucleoKeys


//console.log("nucleo keys",nucleoKeys);
testlib.on( 'ready', function( patterns ) {
	console.log( "Patterns:", patterns );//prints the pattern

	//loop throught the patterns
	patterns.forEach(element => {
		dict[element]=0;
	});
	toCheckKeys=Object.keys(dict); //holding the keys

	//get the longest length string
	longestStrLength=patterns.sort(function (a, b) { return b.length - a.length })[0];

	testlib.frequencyTable(dict);//print table
	testlib.runTests();
} );





testlib.on( 'data', function( data ) {
	//add data to buffer
	buffer.push(data);

	//if current buffer is larger than the largest sequence
	if (buffer.length>longestStrLength.length){
		buffer.shift();
	}

	if (buffer.length!=longestStrLength.length)
	{
		count=0;//this is beacuse the thing is being initalized
	}
	//is the same length as the largest sequence possible
	if (buffer.length===longestStrLength.length)
	{
		//loop through each key 
		toCheckKeys.forEach(element => {
			//get length of the current key
			//and the number of letters to remove
			let checkSize=element.length;
			let sizeToRemove=longestStrLength.length-checkSize;
			
			let finalStr=finalValueOrder(buffer, element, sizeToRemove);
			let finalKey=finalKeyOrder(element);


			let comparingStr=""; //finally changing to str which we can compare
			finalStr.forEach(element => {
				comparingStr=comparingStr+element;
			});


			if (finalKey===comparingStr){ //check if the two String Match
				let num=dict[element];//get current key element value
				num++; //increment that num by 1;
				dict[element]=num; //set the value of num
				testlib.foundMatch(element, count);//if found print
			}

			else //if they dont match, check if letters can be swapped
			{
				let x=compareArrayToTable(nucleoKeys, finalStr);
				if (x==true)//finalStr contains nucleoKeys
				{
					//get the common elements between finalStr and nucleoKeys
					let intersection = finalStr.filter(x => nucleoKeys.includes(x));
					//get the different elements between finaStr and finalKey
					//these are the letters we need to change
					let difference = finalStr.filter(x => !finalKey.includes(x));
			
					let keyPositiontoChange=[];//stores the position of where to change letter
					difference.forEach(currentElem => {
						let x=finalStr.indexOf(currentElem);
						keyPositiontoChange.push(x);
					});

					keyPositiontoChange.forEach(currentElem => {
						let toCheckArray=nucleo.finalStr[(currentElem)].values();
						console.log("Helo", toCheckArray);
						// if (finalStr[Number(keyPositiontoChange)] in finalStr[Number(keyPositiontoChange)].values())
						// {
						// 	console.log("hello");
						// }
					});
					//check if the keys contains the letter we are looking for, for each intersection element we find
					//we can use a possibility, if the key contains the value we are looking for

					// difference.forEach(changeElement => {
					// 	if(changeElement in )
					// });
					//need to find out the position of the finalKey as 
					// intersection.forEach(changeElement => {
					// 	if(changeElement)
					// });

				}
				//else just pass throught to next loop
			}
		});
	}
	count++; //moving to the next letter
});







//when a /n is called
testlib.on('reset', function(data)
{
	testlib.frequencyTable(dict);
});

//end of the stream
testlib.on( 'end', function(data) {
	testlib.frequencyTable(dict);
});

let compareArrayToTable=function findCommonElements3(arr1, arr2) {
    return arr1.some(item => arr2.includes(item))
}
let finalValueOrder=function(buffer, element, sizeToRemove)
{
	//change buffer to str and then back to array
	let comparingStr=buffer.toString();
	comparingStr= comparingStr.split(',').join('');
	comparingStr = comparingStr.split("");

	//remove starting unnecessary letters and then sort alphabetically
	comparingStr.splice(element.length, sizeToRemove);
	//comparingStr.sort();

	let finalStr=""; //finally changing to str which we can compare
	comparingStr.forEach(element => {
		finalStr=finalStr+element;
	});
	
	//console.log(finalStr);
	return comparingStr;
}

let finalKeyOrder=function(element)
{
	//do the same thing for the elements
	let comparingKey=element.toString();
	comparingKey= comparingKey.split(',').join('');
	comparingKey = comparingKey.split("");

	//comparingKey.sort();

	let finalKey=""; //finally changing to str which we can compare
	comparingKey.forEach(element => {
		finalKey=finalKey+element;
	});
	//console.log(finalKey);
	return finalKey;
}

testlib.setup(1); // Runs test 1 (task1.data and task1.seq)