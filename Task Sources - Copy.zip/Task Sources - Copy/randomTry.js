let arr1=["A", "B", "C"];
let arr2=["D", "E", "A"];
let intersection = arr1.filter(x => arr2.includes(x));
console.log(intersection);